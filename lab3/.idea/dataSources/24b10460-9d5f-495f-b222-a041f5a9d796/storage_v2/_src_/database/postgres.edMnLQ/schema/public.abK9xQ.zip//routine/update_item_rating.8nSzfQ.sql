create procedure update_item_rating()
    language plpgsql
as
$$
DECLARE i RECORD;
new_rating RECORD;
BEGIN
   FOR i IN (SELECT DISTINCT id from items) LOOP
    SELECT avg(grade), count(grade) INTO new_rating from reviews where reviews.order_item_id=i.id;
     UPDATE item_ratings SET rating = new_rating.avg, number_of_grades = new_rating.count where item_ratings.item_id=i.id;
   END LOOP;
   FOR i IN (SELECT DISTINCT id from shops) LOOP
     SELECT avg(grade), count(grade) INTO new_rating from order_items join  shop_items on order_items.shop_item_id=shop_items.id join reviews on order_items.id=reviews.order_item_id where shop_id=i.id;
     UPDATE shop_ratings SET rating = new_rating.avg, number_of_grades = new_rating.count where shop_ratings.shop_id=i.id;
   END LOOP;
END; $$;

alter procedure update_item_rating() owner to s311293;

