create function getitemreviews(itemid integer) returns reviews
    language sql
as
$$SELECT reviews FROM reviews JOIN order_items ON order_items.id = reviews.order_item_id JOIN shop_items ON shop_items.id = order_items.shop_item_id WHERE shop_items.item_id = itemId ORDER BY RANDOM();$$;

alter function getitemreviews(integer) owner to s311293;

